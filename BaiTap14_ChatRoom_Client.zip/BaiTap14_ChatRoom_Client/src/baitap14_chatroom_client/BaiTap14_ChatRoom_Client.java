/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package baitap14_chatroom_client;

/**
 *
 * @author Desktop
 */
public class BaiTap14_ChatRoom_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ChatClient chatClient = new ChatClient();
       chatClient.startClient();
    }
    
}
